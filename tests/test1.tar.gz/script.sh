echo "Debut"
ls
echo "hello world" > new_file
ls
cat new_file
